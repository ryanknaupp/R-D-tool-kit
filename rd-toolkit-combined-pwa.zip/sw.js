const CACHE = 'rd-toolkit-v1';
const ASSETS = [
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './excellence/index.html',
  './excellence/manifest.json',
  './excellence/icon-192.png',
  './excellence/icon-512.png',
  './sales/index.html',
  './sales/manifest.json',
  './sales/icon.svg',
  './kpi/index.html',
  './kpi/manifest.json',
  './kpi/icon-192.svg',
  './kpi/icon-512.svg'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(cached => cached || fetch(e.request))
  );
});
